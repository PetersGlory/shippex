export const PRIMARY_COLOR = "#2F50C1";
export const PRIMARY_WHITE = "#ffffff";
export const PRIMARY_INDIGO = "#6E91EC";
export const PRIMARY_GREEN = "#25D366";